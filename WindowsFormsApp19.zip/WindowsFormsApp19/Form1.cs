﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp19
{
    public partial class Form1 : Form
    {
        public RectangleF Circle { get; private set; }
        public RectangleF Square { get; private set; }
        public RectangleF Rectangle { get; private set; }
        public bool RectagleClicked { get; private set; }
        public float RectangleX { get; private set; }
        public float RectangleY { get; private set; }
        public bool SquareClicked { get; private set; }
        public float SquareX { get; private set; }
        public float SquareY { get; private set; }
        public bool CircleClicked { get; private set; }
        public float CircleX { get; private set; }
        public float CircleY { get; private set; }

        public Form1()
        {
            InitializeComponent();
        }



        private void pictureBox1_Paint(object sender, PaintEventArgs e)
        {

            e.Graphics.FillEllipse(Brushes.Red, Circle);
            e.Graphics.FillRectangle(Brushes.Blue, Square);
            e.Graphics.FillRectangle(Brushes.Yellow, Rectangle);
        }

        private void pictureBox1_MouseDown(object sender, MouseEventArgs e)
        {
            if ((e.X < Rectangle.X + Rectangle.Width) && (e.X > Rectangle.X))
            {
                {
                    if ((e.Y < Rectangle.Y + Rectangle.Height) && (e.Y > Rectangle.Y))
                    {
                        RectagleClicked = true;

                        RectangleX = e.X - Rectangle.X;
                        RectangleY = e.Y - Rectangle.Y;
                    }
                }
            }
            if ((e.X < Square.X + Square.Width) && (e.X > Square.X))
            {
                {
                    if ((e.Y < Square.Y + Square.Height) && (e.Y > Square.Y))
                    {
                        SquareClicked = true;

                        SquareX = e.X - Square.X;
                        SquareY = e.Y - Square.Y;
                    }
                }
            }
            if ((e.X < Circle.X + Circle.Width) && (e.X > Circle.X))
            {
                {
                    if ((e.Y < Circle.Y + Circle.Height) && (e.Y > Circle.Y))
                    {
                        CircleClicked = true;

                        CircleX = e.X - Circle.X;
                        CircleY = e.Y - Circle.Y;
                    }
                }
            }
        }

        private void pictureBox1_MouseUp(object sender, MouseEventArgs e)
        {
            if ((e.X < Rectangle.X + Rectangle.Width) && (e.X > Rectangle.X))
            {
                {
                    if ((e.Y < Rectangle.Y + Rectangle.Height) && (e.Y > Rectangle.Y))
                    {
                        RectagleClicked = false;

                        RectangleX = e.X - Rectangle.X;
                        RectangleY = e.Y - Rectangle.Y;
                    }
                }
            }
            if ((e.X < Square.X + Square.Width) && (e.X > Square.X))
            {
                {
                    if ((e.Y < Square.Y + Square.Height) && (e.Y > Square.Y))
                    {
                        SquareClicked = false;

                        SquareX = e.X - Square.X;
                        SquareY = e.Y - Square.Y;
                    }
                }
            }
            if ((e.X < Circle.X + Circle.Width) && (e.X > Circle.X))
            {
                {
                    if ((e.Y < Circle.Y + Circle.Height) && (e.Y > Circle.Y))
                    {
                        CircleClicked = false;

                        CircleX = e.X - Circle.X;
                        CircleY = e.Y - Circle.Y;
                    }
                }
            }
        }

        private void pictureBox1_MouseMove(object sender, MouseEventArgs e)
        {
            if (CircleClicked)
            {
                CircleX = e.X - Circle.X;
                CircleY = e.Y - Circle.Y;
            }
            if (RectagleClicked)
            {
                RectangleX = e.X - Rectangle.X;
                RectangleY = e.Y - Rectangle.Y;
            }
            if (SquareClicked)
            {
                SquareX = e.X - Square.X;
                SquareY = e.Y - Square.Y;
            }
            pictureBox1.Invalidate();

            if ((label1.Location.X < Square.X + Square.Width) && (label1.Location.X > Square.X))
            {
                if ((label1.Location.Y < Square.Y + Square.Height) && ( label1.Location.Y > Square.Y))
                {
                    label3.Text = "Синий КвадраT";
                }
            }
            if ((label1.Location.X < Rectangle.X + Rectangle.Width) && (label1.Location.X > Rectangle.X))
            {
                if ((label1.Location.Y < Rectangle.Y + Rectangle.Height) && (label1.Location.Y > Rectangle.Y))
                {
                    label3.Text = "Желтый ПрямоугольниК";
                }
            }
            if ((label1.Location.X < Circle.X + Circle.Width) && (label1.Location.X > Circle.X))
            {
                if ((label1.Location.Y < Circle.Y + Circle.Height) && (label1.Location.Y > Circle.Y))
                {
                    label3.Text = "Krasniy KruG";
                }
            }
            int X, Y, dX, dY;x
            int LastClicked = 0;

        }
    }
}
