﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp19
{
    static class Program
    {
        public partial class ЛабараорнаяРабота4 : Form
        {
            Rectangle Rectangle = new Rectangle(10, 10, 200, 100);
            Rectangle Circle = new Rectangle(220, 20, 150, 150);
            Rectangle Square = new Rectangle(380, 10, 150, 150);
            bool RectagleClicked = false;
            bool CircleClicked = false;
            bool SquareClicked = false;
            int RectangleX = 0;
            int RectangleY = 0;
            int CircleX = 0;
            int CircleY = 0;
            int SquareX = 0;
            int SquareY = 0;
            int X = 0;
            int Y = 0;
        }

        /// <summary>
        /// Главная точка входа для приложения.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form1());
        }

    }
}
